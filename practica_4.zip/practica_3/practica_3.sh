#!/bin/bash
#821342, Cuesta, Jorge, T, 1, B
#875112, Berga, Tahir, T, 1, B

# Número de parámetros correcto
if [ $# -ne 2 ]; then
    echo "Número incorrecto de parámetros" 1>&2
    exit 1
fi

# Privilegios de administrador
if [ "$EUID" -ne 0 ]; then
    echo "Este script necesita privilegios de administración" 1>&2
    exit 1
fi

case $1 in
    -a)
        # Añadir usuario
        while IFS=, read -r name passwd fullname resto; do
            if [ -z "$name" ] || [ -z "$passwd" ] || [ -z "$fullname" ]; then
                echo "Campo inválido" 1>&2
                exit 1
            fi

            # Verificar si el usuario ya existe
            if getent passwd "$name" > /dev/null; then
                echo "El usuario $name ya existe"
                continue
            fi

            # Añadir usuario
            useradd -K PASS_MAX_DAYS=30 -K UID_MIN=1815 -U -m -k /etc/skel -c "$fullname" "$name"
            echo "$name:$passwd" | chpasswd
            usermod -U "$name"
            echo "$fullname ha sido creado"
        done < "$2"
        ;;
    -s)
        # Borrar usuario y Backup
        mkdir -p /extra/backup

        while IFS=, read -r name resto; do
            if [ -z "$name" ]; then
                echo "Campo inválido" 1>&2
                exit 1
            fi

            # Usuario existe y no es root
            if getent passwd "$name" > /dev/null && [ "$name" != "root" ]; then
                home_dir=$(getent passwd "$name" | cut -d: -f6)
                if tar cfP "/extra/backup/${name}.tar" "$home_dir"; then
                    userdel -r "$name" 2>/dev/null
                    echo "El usuario $name y su directorio han sido eliminados correctamente."
                else
                    echo "Error al crear el backup de $name."
                fi
            fi
        done < "$2"
        ;;
    *)
        # Opción inválida
        echo "Opción inválida" 1>&2
        exit 1
        ;;
esac

