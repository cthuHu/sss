#!/bin/bash
#821342, Cuesta, Jorge, T, 1, B
#875112, Berga, Tahir, T, 1, B

# Validar número correcto de argumentos
if [ "$#" -ne 3 ]; then
    echo "Número incorrecto de parámetros" 1>&2
    exit 1
fi

# Comprobar privilegios de root
if [ "$EUID" -ne 0 ]; then
    echo "Este script necesita privilegios de administración" 1>&2
    exit 1
fi

# Archivo de usuarios y máquinas
file_users="$2"
file_machines="$3"

# Función para ejecutar comandos en máquinas remotas
execute_remotely() {
    local machine=$1
    local command=$2

    if ! ssh -i /home/tahir/.ssh/id_ed25519 as@"$machine" "$command"; then
        echo "$machine no es accesible" 1>&2
        return 1
    fi
}

# Leer archivo de máquinas y ejecutar la acción correspondiente
while IFS= read -r machine; do
    [ -z "$machine" ] && continue # Ignorar líneas vacías

    case $1 in
        -a)
            # Procesar cada usuario del archivo de usuarios
            while IFS= read -r user_info; do
                echo "Procesando línea de usuario: $user_info"  # Depuración
                IFS=',' read -r username password fullname <<< "$user_info"
                echo "Procesando línea de usuario:$username "
                echo "Procesando línea de contra:$password "
                echo "Procesando línea de full:$fullname"
                if [ -z "$username" ] || [ -z "$password" ] || [ -z "$fullname" ]; then
                    echo "Información de usuario incompleta: $user_info" 1>&2
                    continue
                fi
                add_command="sudo useradd -m -c \"$fullname\" -s /bin/bash $username && echo \"$username:$password\" | chpasswd"
                execute_remotely "$machine" "$add_command"
            done < "$file_users"
            ;;
        -s)
            # Eliminar usuario
            while IFS= read -r user_info; do
                echo "Procesando línea de usuario: $user_info"  # Depuración
                username=$(echo "$user_info" | cut -d',' -f1)
                echo "Procesando línea de usuario: $username" 
                if [ -z "$username" ]; then
                    echo "Información de usuario incompleta para eliminación: $user_info" 1>&2
                    continue
                fi
                del_command="sudo userdel -r $username"
                execute_remotely "$machine" "$del_command"
            done < "$file_users"
            ;;
        *)
            echo "Opción inválida" 1>&2
            exit 1
            ;;
    esac
done < "$file_machines"

exit 0

