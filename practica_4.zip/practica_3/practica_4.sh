#!/bin/bash
#821342, Cuesta, Jorge, T, 1, B
#875112, Berga, Tahir, T, 1, B

#Comprobamos el numero de parametros
if [ $# -ne 3 ]
then
#Si NO es igual a 3 el numero de parametros mensaje de error
echo "Numero incorrecto de parametros" 1>&2
exit 1
else
#Recorremos el fichero con las direcciones ip de las maquinas y les pasamos practica_4.sh, ademas del fichero de usuarios
while read -r ip
do
if ping -c 1 "$ip" >/dev/null;
then
scp -q -i "~/.ssh/id_as_ed25519" "./practica_4_1.sh" "$2"
"as@$ip:~"
ssh -q -i "~/.ssh/id_as_ed25519" "as@$ip" "sudo
~/./practica_4_1.sh "$1" "$2" ; rm ~/practica_4_1.sh ~/$2" < /dev/null
else
# se muestra un mensaje de error si no nos podemos conectar a
la maquina indicada
echo "No se ha podido conectar a la maquina "$ip"" 1>&2
fi
done < "$3"
fi
