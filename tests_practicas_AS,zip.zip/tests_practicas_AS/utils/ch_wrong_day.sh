#!/bin/bash
#147848, Galindo, Beatriz, M, 7, A"


