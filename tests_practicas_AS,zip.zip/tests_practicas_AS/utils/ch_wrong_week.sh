#!/bin/bash
#147848, Galindo, Beatriz, M, 2, D"


