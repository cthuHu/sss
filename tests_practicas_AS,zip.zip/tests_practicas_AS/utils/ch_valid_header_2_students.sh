#!/bin/bash
#214748, Galindo, Beatriz, T, 2, A"
#429496, Wilkes, Maurice, T, 2, A"

