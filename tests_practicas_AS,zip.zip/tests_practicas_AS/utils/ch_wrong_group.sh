#!/bin/bash
#147848, Galindo, Beatriz, Z, 2, A"


