#!/bin/bash

#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

# Pide al usuario que introduzca el nombre del archivo
echo "Introduzca el nombre del fichero: "
read nombre_archivo

# Verifica si el archivo existe
if [ ! -e "$nombre_archivo" ]; then
    echo "$nombre_archivo no existe"
else
    # Inicializa la variable de permisos
    permisos=""

    # Verifica cada uno de los permisos: lectura, escritura y ejecución
    [ -r "$nombre_archivo" ] && permisos="${permisos}r" || permisos="${permisos}-"
    [ -w "$nombre_archivo" ] && permisos="${permisos}w" || permisos="${permisos}-"
    [ -x "$nombre_archivo" ] && permisos="${permisos}x" || permisos="${permisos}-"

    # Muestra los permisos del archivo
    echo "Los permisos del archivo $nombre_archivo son: $permisos"
fi

