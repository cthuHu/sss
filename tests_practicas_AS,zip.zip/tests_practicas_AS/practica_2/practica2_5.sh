#!/bin/bash

#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

echo "Introduzca el nombre de un directorio: "
read dir

if [ -d "$dir" ]; then
    num_files=$(find "$dir" -maxdepth 1 -type f | wc -l)
    num_dirs=$(find "$dir" -maxdepth 1 -type d | wc -l)
    num_dirs=$((num_dirs - 1)) # Excluye el directorio padre
    echo "El numero de ficheros y directorios en $dir es de $num_files y $num_dirs, respectivamente"
else
    echo "$dir no es un directorio"
fi

