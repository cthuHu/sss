#!/bin/bash
#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

# Función para verificar y mostrar archivos
mostrar_archivo() {
    if [ -f "$1" ]; then
        more "$1"
    else
        echo "$1 no es un fichero"
    fi
}

# Itera sobre todos los parámetros usando "$@"
for archivo in "$@"; do
    mostrar_archivo "$archivo"
done

