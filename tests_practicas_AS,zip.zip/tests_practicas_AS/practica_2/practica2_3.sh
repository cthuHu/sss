#!/bin/bash

#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

# Verifica la cantidad de parámetros
if [ "$#" -ne 1 ]; then
    echo "Sintaxis: practica2_3.sh <nombre_archivo>"
    exit 1
fi

archivo=$1

# Verifica si el archivo existe y es un archivo común
if [ -f "$archivo" ]; then
    chmod ug+x "$archivo"
    stat -c "%A" "$archivo"
else
    echo "$archivo no existe"
fi

