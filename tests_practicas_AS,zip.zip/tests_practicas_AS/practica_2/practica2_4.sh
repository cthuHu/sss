#!/bin/bash

#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

echo "Introduzca una tecla: "
read -n 1 tecla
echo ""

case $tecla in
    [a-zA-Z]) echo "$tecla es una letra" ;;
    [0-9]) echo "$tecla es un numero" ;;
    *) echo "$tecla es un caracter especial" ;;
esac

