#!/bin/bash

#Jorge Cuesta, NIP: 821342
#Tahir Berga, NIP: 875112

# Creación del subdirectorio temporal
dir_temp=$(mktemp -d ~/binXXX)

echo "Directorio destino de copia: $dir_temp"

contador=0

for archivo in *; do
    if [ -x "$archivo" ] && [ -f "$archivo" ]; then
        cp "$archivo" "$dir_temp"
        echo "$archivo ha sido copiado a $dir_temp"
        ((contador++))
    fi
done

if [ $contador -eq 0 ]; then
    echo "No se ha copiado ningun archivo"
else
    echo "Se han copiado $contador archivos"
fi

